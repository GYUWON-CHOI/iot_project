import RPi.GPIO as GPIO
import spidev
import time

spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 100000

def ReadVol(vol):
    adc = spi.xfer2([1, 8 + vol << 4, 0])
    data = ((adc[1] & 3) << 8) + adc[2]
    return data

mcp3008 = 0

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)

p = GPIO.PWM(4, 50)
p.start(0)

while True:
    a_1 = ReadVol(mcp3008)
    value = a_1 / 1023 * 100
    print('Value : ', value)
    p.ChangeDutyCycle(value)
    time.sleep(0.5)
