#!/usr/bin/python3
print("Content-type: text/html\r\n")
print("<html><head><title>Python CGI Test</title></head>")
print("<body><h3>Python CGI Test Page</h3></body>")
print("</html>")
