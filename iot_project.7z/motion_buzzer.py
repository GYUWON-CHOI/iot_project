import RPi.GPIO as GPIO
import time

sensor = 17

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(sensor, GPIO.IN)
GPIO.setup(4, GPIO.OUT)

time.sleep(5)

p = GPIO.PWM(4, 50)
p.start(0)

try:
    while True:
        if GPIO.input(sensor) == 1:
            p.start(50)
            p.ChangeFrequency(1500)
            print("Motion Detacted!")
            time.sleep(2)
        else:
            p.start(0)
            p.ChangeFrequency(500)
            time.sleep(1)
            
except KeyboardInterrupt:
    print("interrupted...")
    GPIO.cleanup()
