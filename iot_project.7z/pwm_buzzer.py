import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)

p = GPIO.PWM(4, 50)
p.start(50)

try:
    while True:
        p.ChangeFrequency(500)
        time.sleep(0.5)
        
        p.ChangeFrequency(1000)
        time.sleep(0.5)
        
except KeyboardInterrupt:
    pass
p.stop()
GPIO.cleanup()
