#!/usr/bin/python3
from gpiozero import Button
from picamera2 import Picamera2, Preview
from time import sleep

#create buttons and a PiCamera objects
button1 = Button(2) # capture still image
button2 = Button(3) # quit the program
camera = Picamera2()
camera_config = camera.create_still_configuration(main={"size": (1920, 1028)},lores={"size": (640, 480)}, display="lores")
camera.configure(camera_config)
camera.start_preview(Preview.QTGL)
camera.start()
sleep(2)

# var for quit button press
quit_flag = False

# var for image serial number
i = 0

# stop the camera and set the quit_flag when the quit button pressed
def quit_camera():
    global quit_flag
    camera.stop_preview()
    camera.stop()
    quit_flag = True

# take still image when the capture button pressed
def capture_image():
    global i
    i = i + 1
    camera.capture_file('image_{}.jpg'.format(i))
    print('still image taken')
    sleep(3)
    
# register a function that capture a image when the button1 pressed
button1.when_pressed = capture_image

# register a function that quit the camera when the button2 pressed
button2.when_pressed = quit_camera

# loop until the quit button pressed
while True:
    if quit_flag == False:
        sleep(1)
else:
    exit(0)