#!/usr/bin/python3
import RPi.GPIO as GPIO
from picamera2 import Picamera2, Preview
from time import sleep

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
pirPin = 17
GPIO.setup(pirPin, GPIO.IN, GPIO.PUD_UP)
GPIO.setup(4, GPIO.OUT)
p = GPIO.PWM(4, 50)
camera = Picamera2()
camera_config = camera.create_still_configuration(main={"size": (1920, 1028)},lores={"size": (640, 480)}, display="lores")
camera.configure(camera_config)
camera.start_preview(Preview.QTGL)
camera.start()
i = 0
quit_flag = False
p.start(0)
# loop until the quit button pressed
while True:
    if GPIO.input(pirPin) == 1:
        i = i + 1
        camera.capture_file('image_{}.jpg'.format(i))
        p.start(50)
        p.ChangeFrequency(1500)
        print('still image taken')
        sleep(2)
    else:
        p.start(0)
        p.ChangeFrequency(1)
        sleep(1)
