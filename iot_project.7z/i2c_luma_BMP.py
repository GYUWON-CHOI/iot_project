#!/usr/bin/python3
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306
import time
from bmp280 import BMP280
from smbus2 import SMBus

# substitute spi(device=0, port=0) below if using that interface
serial = i2c(port=1, address=0x3C)
device = ssd1306(serial)

bus = SMBus(1)
bmp280 = BMP280(i2c_dev = bus)

while True:
    temperature = bmp280.get_temperature()
    pressure = bmp280.get_pressure()
    
    with canvas(device) as draw:
        
        draw.rectangle(device.bounding_box, outline="white", fill="black")
        draw.text((30, 20), 'Temperature = {:.2f}c'.format(temperature), fill="white")

