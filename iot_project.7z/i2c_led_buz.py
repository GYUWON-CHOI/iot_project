import RPi.GPIO as GPIO
import time
from bmp280 import BMP280
from smbus2 import SMBus

led_blue = 20

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)
GPIO.setup(led_blue, GPIO.OUT)

print("press ctrl-c to stop!")

p = GPIO.PWM(4, 50)
p.start(0)

bus = SMBus(1)
bmp280 = BMP280(i2c_dev = bus)

while True:
    try:
        temperature = bmp280.get_temperature()
        pressure = bmp280.get_pressure()
        print('Temperature = {:.2f}c'.format(temperature))
        print('pressure = {:.1f}hPa'.format(pressure))
        print("===============================")
        if temperature >= 30:
            GPIO.output(led_blue, 1)
            p.start(50)
            p.ChangeFrequency(1500)
        else:
            GPIO.output(led_blue, 0)
            p.start(0)
            p.ChangeFrequency(500)
        time.sleep(3)
    except KeyboardInterrupt:
        exit(0)
